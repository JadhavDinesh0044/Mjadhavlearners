package welcome;

public class Phase1Ap3 {
	//user defined method
   static void resp() {
	   System.out.println("hello jadhav");
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calling the userdefined method
		resp();
		//predefined method by system
		System.out.println("the power of no is: "+Math.pow(2, 3));

	}

}
