package welcome;

public class Phase1Ap9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		//initializing,declaring an array
      int arr[]= {2,3,5,2};
      //for loop used to iterate over array 
      for(int i=0;i<arr.length;i++) {
    	  sum=sum+arr[i];//adding the elements in array
      }
      System.out.println("the total count is: "+sum);
      
	}

}
