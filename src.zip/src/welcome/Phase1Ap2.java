package welcome;
import Welcome2.*;
//for showing the example of private Im making the code comments because its show compile time error;
//creating private modifies with help of another class
//according to private modifier we cannot access the data from another class

/*class B{
	private int i=2;
	private void msg() {
		System.out.println("word");
	}
}

public class Phase1Ap2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		System.out.println(obj.i);//compile time error because we cannot access private members from another class;
		//this is for default access modifier below code 
		Ap2 ob=new Ap2();
		ob.mess();//shows compile time error for default access modifier

	}

}*/
