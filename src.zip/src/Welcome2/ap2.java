package Welcome2;
//default access modifier ,we cannot access the data from outside the other package;

class ap2 {
	
void mess() {
	System.out.println("dinesh");
}
}
